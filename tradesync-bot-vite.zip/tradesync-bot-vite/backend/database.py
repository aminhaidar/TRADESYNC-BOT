import sqlite3
from flask import current_app, g
import os
import logging

logger = logging.getLogger(__name__)

def get_db_connection():
    """Get a connection to the SQLite database."""
    try:
        db_uri = current_app.config['DATABASE_URI']
        logger.info(f"Getting connection to database: {db_uri}")
        
        # Extract the file path from SQLite URI
        if db_uri.startswith('sqlite:///'):
            # Handle relative path (sqlite:///trades.db)
            if db_uri.startswith('sqlite:////'):
                # Absolute path with 4 slashes
                db_path = db_uri[9:]
            else:
                # Relative path with 3 slashes
                db_path = db_uri[10:]
                
            logger.info(f"Extracted database path: {db_path}")
            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row
            logger.info(f"Successfully connected to database at {db_path}")
            return conn
        else:
            logger.error(f"Unsupported database URI: {db_uri}")
            raise ValueError(f"Unsupported database URI: {db_uri}")
    except Exception as e:
        logger.error(f"Error connecting to database: {str(e)}")
        raise
