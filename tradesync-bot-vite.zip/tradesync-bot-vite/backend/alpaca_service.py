import os
from logging import getLogger
from alpaca_trade_api.rest import REST

logger = getLogger(__name__)

ALPACA_API_KEY = os.getenv('ALPACA_API_KEY')
ALPACA_SECRET_KEY = os.getenv('ALPACA_SECRET_KEY')
ALPACA_BASE_URL = 'https://paper-api.alpaca.markets'

alpaca_client = REST(ALPACA_API_KEY, ALPACA_SECRET_KEY, base_url=ALPACA_BASE_URL)

def fetch_stock_data(symbol):
    try:
        # For indices like SPX and VIX, Alpaca doesn't provide direct snapshot data
        # We'll return mock data for testing purposes
        if symbol in ['SPX', 'VIX']:
            logger.warning(f"Mock data for {symbol} as Alpaca does not support direct snapshot")
            return {
                'symbol': symbol,
                'price': 5100.0 if symbol == 'SPX' else 15.0,
                'change': 0.5 if symbol == 'SPX' else 1.0,
                'volume': 'N/A'
            }

        # For regular stocks (QQQ, IWM)
        snapshot = alpaca_client.get_snapshot(symbol)
        daily_bar = snapshot.daily_bar if hasattr(snapshot, 'daily_bar') else None
        change = daily_bar.change if daily_bar and hasattr(daily_bar, 'change') else 0.0
        return {
            'symbol': symbol,
            'price': snapshot.latest_trade.price,
            'change': change,
            'volume': snapshot.latest_trade.size
        }
    except Exception as e:
        logger.error(f"Error fetching data for {symbol}: {str(e)}")
        return {'symbol': symbol, 'price': 'N/A', 'change': 'N/A', 'volume': 'N/A'}

def get_alpaca_portfolio():
    try:
        account = alpaca_client.get_account()
        positions = alpaca_client.list_positions()
        return {
            'cash': float(account.cash),
            'positions': [
                {
                    'symbol': pos.symbol,
                    'qty': int(pos.qty),
                    'avg_entry_price': float(pos.avg_entry_price),
                    'current_price': float(pos.current_price),
                    'market_value': float(pos.market_value),
                    'profit_loss': float(pos.unrealized_pl)
                } for pos in positions
            ],
            'total_value': float(account.equity)
        }
    except Exception as e:
        logger.error(f"Error fetching Alpaca portfolio: {str(e)}")
        return {'cash': 10000, 'positions': [], 'total_value': 10000}
