import os
from alpaca_trade_api.rest import REST
from logging import getLogger

logger = getLogger(__name__)

ALPACA_API_KEY = os.getenv('ALPACA_API_KEY')
ALPACA_SECRET_KEY = os.getenv('ALPACA_SECRET_KEY')
ALPACA_BASE_URL = 'https://paper-api.alpaca.markets'

alpaca_client = REST(ALPACA_API_KEY, ALPACA_SECRET_KEY, base_url=ALPACA_BASE_URL)

def execute_trade(alert):
    if not alert.get('symbol') or not alert.get('action'):
        logger.warning("Invalid trade alert: missing symbol or action")
        return {'status': 'error', 'message': 'Invalid trade alert'}

    # Skip execution for mock alerts (e.g., when DISCORD_WEBHOOK_URL is not set)
    if not os.getenv('DISCORD_WEBHOOK_URL'):
        logger.info("Skipping trade execution due to mock alert")
        return {'status': 'skipped', 'message': 'Mock alert, no execution'}

    try:
        account = alpaca_client.get_account()
        total_balance = float(account.equity)
        max_trade_amount = total_balance * 0.20  # 20% of account balance

        trade_cost = float(alert.get('price', 0)) * int(alert.get('contracts', 1))
        if trade_cost > max_trade_amount:
            logger.warning(f"Trade cost ({trade_cost}) exceeds 20% of account balance ({max_trade_amount})")
            return {'status': 'not_traded', 'message': 'Trade exceeds 20% of account balance'}

        if float(account.cash) < trade_cost:
            logger.error("Error executing trade: insufficient buying power")
            return {'status': 'error', 'message': 'Insufficient buying power'}

        # Simulate trade execution (replace with actual order placement)
        order = alpaca_client.submit_order(
            symbol=alert['symbol'],
            qty=int(alert.get('contracts', 1)),
            side=alert['action'].lower(),
            type='limit',
            time_in_force='gtc',
            limit_price=float(alert.get('price', 0))
        )
        logger.info(f"Trade executed successfully: {order}")
        return {'status': 'success', 'message': 'Trade executed', 'order': order.id}
    except Exception as e:
        logger.error(f"Error executing trade: {str(e)}")
        return {'status': 'error', 'message': str(e)}
