import os
import logging
import datetime
import threading
import time
import sqlite3
from flask import Flask, jsonify
from flask_cors import CORS
from flask_socketio import SocketIO, emit
from dotenv import load_dotenv
from trade_routes import trade_routes
from fetch_samples import fetch_discord_alerts, parse_trade_alert
from alpaca_service import fetch_stock_data, get_alpaca_portfolio
from trade_executor import execute_trade
from database import get_db_connection

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("logs/app.log"),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": "*"}})
app.config['DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///trades.db')
logger.info(f"Using DATABASE_URI: {app.config['DATABASE_URI']}")

# Initialize WebSocket with additional configuration
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='gevent', logger=True, engineio_logger=True)

# Register API routes
app.register_blueprint(trade_routes, url_prefix="/api")

# Thread lock for database synchronization
db_lock = threading.Lock()

# Setup database within application context
with app.app_context():
    def setup_database():
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS trades (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    symbol TEXT NOT NULL,
                    action TEXT NOT NULL,
                    quantity INTEGER NOT NULL,
                    price REAL,
                    status TEXT NOT NULL,
                    timestamp TEXT NOT NULL
                )
            """)
            conn.commit()
            logger.info("Database setup completed successfully: trades table created or verified")
        except Exception as e:
            logger.error(f"Error setting up database: {str(e)}")
            raise
        finally:
            if 'conn' in locals():
                conn.close()

    setup_database()

### API ENDPOINTS ###
@app.route("/api/market_data", methods=["GET"])
def get_market_data():
    try:
        indices = {
            "SPX": fetch_stock_data("SPX"),
            "QQQ": fetch_stock_data("QQQ"),
            "IWM": fetch_stock_data("IWM"),
            "VIX": fetch_stock_data("VIX"),
        }
        socketio.emit("indices_update", indices)
        return jsonify(indices)
    except Exception as e:
        logger.error(f"Error fetching market data: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route("/api/portfolio", methods=["GET"])
def get_portfolio():
    try:
        portfolio_data = get_alpaca_portfolio()
        socketio.emit("portfolio_update", portfolio_data)
        return jsonify(portfolio_data)
    except Exception as e:
        logger.error(f"Error fetching portfolio: {str(e)}")
        return jsonify({"error": str(e)}), 500

# Add this to app.py under existing API endpoints
@app.route("/api/trades", methods=["GET"])
def get_trades():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT symbol, action, quantity, price, status, timestamp FROM trades ORDER BY timestamp DESC LIMIT 5")
        trades = [
            {
                "symbol": row[0],
                "action": row[1],
                "quantity": row[2],
                "price": row[3],
                "status": row[4],
                "timestamp": row[5]
            } for row in cursor.fetchall()
        ]
        conn.close()
        return jsonify(trades)
    except Exception as e:
        logger.error(f"Error fetching trades: {str(e)}")
        return jsonify({"error": str(e)}), 500

### WEBSOCKETS ###
@socketio.on("connect")
def handle_connect():
    logger.info("Client connected")
    emit("status", {"status": "connected"})

@socketio.on("disconnect")
def handle_disconnect():
    logger.info("Client disconnected")

@socketio.on("refresh_data")
def handle_refresh():
    logger.info("Client requested data refresh")
    try:
        indices = {
            "SPX": fetch_stock_data("SPX"),
            "QQQ": fetch_stock_data("QQQ"),
            "IWM": fetch_stock_data("IWM"),
            "VIX": fetch_stock_data("VIX"),
        }
        emit("indices_update", indices)
    except Exception as e:
        logger.error(f"Error refreshing data: {str(e)}")
        emit("error", {"message": f"Error refreshing data: {str(e)}"})

### TRADE ALERT FETCHING AND FORWARDING ###
def fetch_and_forward_alerts():
    while True:
        logger.info("Starting fetch_and_forward_alerts loop")
        try:
            logger.info("Attempting to fetch Discord alerts")
            alert_message = fetch_discord_alerts()
            if alert_message:
                logger.info(f"Raw alert fetched: {alert_message}")
                parsed_alert = parse_trade_alert(alert_message)
                if parsed_alert:
                    logger.info(f"Parsed alert: {parsed_alert}")
                    trade_data = {
                        "symbol": parsed_alert.get("symbol", ""),
                        "action": parsed_alert.get("action", ""),
                        "quantity": int(parsed_alert.get("contracts", "1").split()[0]) if "contracts" in parsed_alert else 1,
                        "price": float(parsed_alert.get("price", 0.0)) if parsed_alert.get("price") else None,
                        "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    }
                    execution_result = execute_trade(parsed_alert)
                    trade_data["status"] = execution_result["status"]
                    parsed_alert['execution'] = execution_result
                    socketio.emit('trade_alert', parsed_alert, namespace='/')
                    logger.info(f"Forwarded trade alert: {parsed_alert}")
                    with db_lock:  # Synchronize database access
                        with app.app_context():
                            conn = get_db_connection()
                            cursor = conn.cursor()
                            cursor.execute(
                                "INSERT INTO trades (symbol, action, quantity, price, status, timestamp) VALUES (?, ?, ?, ?, ?, ?)",
                                (trade_data["symbol"], trade_data["action"], trade_data["quantity"], trade_data["price"], trade_data["status"], trade_data["timestamp"])
                            )
                            conn.commit()
                            logger.info("Stored trade in 'trades' table")
                            conn.close()
                else:
                    logger.warning("Failed to parse alert")
            else:
                logger.warning("No alert fetched from Discord")

            # Fetch and emit market data every 10 seconds for real-time updates
            try:
                indices = {
                    "SPX": fetch_stock_data("SPX"),
                    "QQQ": fetch_stock_data("QQQ"),
                    "IWM": fetch_stock_data("IWM"),
                    "VIX": fetch_stock_data("VIX"),
                }
                socketio.emit("indices_update", indices)
                logger.info("Emitted real-time market data update")
            except Exception as e:
                logger.error(f"Error fetching market data for real-time update: {str(e)}")

        except Exception as e:
            logger.error(f"Error in fetch_and_forward_alerts: {str(e)}")
        logger.info("Sleeping for 10 seconds")
        time.sleep(10)

### HEALTH CHECK ###
@app.route("/health", methods=["GET"])
def health_check():
    return jsonify(
        {
            "status": "healthy",
            "timestamp": datetime.datetime.now().isoformat(),
        }
    )

if __name__ == "__main__":
    # Start the alert fetching thread
    threading.Thread(target=fetch_and_forward_alerts, daemon=True).start()
    port = int(os.getenv("PORT", 5000))
    logger.info(f"Starting server on port {port}")
    socketio.run(app, host="0.0.0.0", port=port, allow_unsafe_werkzeug=True)
