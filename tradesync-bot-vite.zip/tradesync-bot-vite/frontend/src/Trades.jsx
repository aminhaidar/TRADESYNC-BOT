// src/Trades.jsx
import React, { useState, useEffect } from 'react';
import ErrorBoundary from './ErrorBoundary';

function Trades({ socket }) {
  const [trades, setTrades] = useState([]);
  const [alerts, setAlerts] = useState([
    {
      id: 'welcome',
      type: 'info',
      title: 'Welcome to TradeSync!',
      message: 'Configure your trade alerts to receive notifications about market opportunities.',
      actions: [{ label: 'Set Up Alerts', type: 'primary' }],
    },
  ]);

  useEffect(() => {
    // Fetch initial trades
    fetch(`${import.meta.env.VITE_BACKEND_URL || 'http://localhost:5000'}/api/trades`)
      .then(res => {
        if (!res.ok) {
          throw new Error(`HTTP error! status: ${res.status}`);
        }
        return res.json();
      })
      .then(data => {
        setTrades(Array.isArray(data) ? data.slice(0, 5) : []);
      })
      .catch(error => {
        console.error('Error fetching trades:', error);
        setTrades([]);
      });

    // Listen for new trade alerts
    socket.on('trade_alert', (alert) => {
      setTrades(prev => [
        {
          symbol: alert.symbol || '',
          action: alert.action || '',
          quantity: parseInt(alert.contracts) || 1,
          price: parseFloat(alert.price) || 0.0,
          status: alert.execution?.status || 'pending',
          timestamp: new Date().toISOString(),
        },
        ...prev,
      ].slice(0, 5)); // Limit to last 5 trades

      // Add new trade alert to alerts
      setAlerts(prev => [
        {
          id: Date.now().toString(),
          type: (alert.action || '').toLowerCase() === 'buy' ? 'success' : 'danger',
          title: `${(alert.action || 'Unknown') === 'BUY' ? 'Momentum Alert' : 'Bearish Pattern'}: ${alert.symbol || 'Unknown'}`,
          message: (alert.action || 'Unknown') === 'BUY'
            ? `${alert.symbol || 'Unknown'} is showing strong upward momentum with increasing volume. Consider a long position.`
            : `${alert.symbol || 'Unknown'} has formed a bearish pattern on the 4-hour chart. Consider reducing exposure.`,
          meta: [
            { icon: 'fas fa-chart-line', text: `Price: $${parseFloat(alert.price) || 0.0}` },
            { icon: 'fas fa-calendar', text: new Date().toLocaleDateString() },
            { icon: 'fas fa-signal', text: (alert.action || 'Unknown') === 'BUY' ? 'Strong Signal' : 'Moderate Signal' },
          ],
          actions: [
            { label: 'Execute', type: (alert.action || '').toLowerCase() === 'buy' ? 'success' : 'danger' },
            { label: 'Analyze', type: 'outline' },
            { label: 'Dismiss', type: 'outline' },
          ],
        },
        ...prev,
      ].slice(0, 5));
    });

    return () => {
      socket.off('trade_alert');
    };
  }, [socket]);

  const handleAlertAction = (alertId, action) => {
    if (action === 'Dismiss') {
      setAlerts(prev => prev.filter(alert => alert.id !== alertId));
    } else {
      console.log(`Action ${action} for alert ${alertId}`);
    }
  };

  const formatCurrency = (value) => {
    if (!value || isNaN(value)) return '$0.00';
    const numValue = parseFloat(value);
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(numValue);
  };

  const getOrderStatusClass = (status) => {
    if (!status) return 'pending';
    switch (status.toLowerCase()) {
      case 'filled':
        return 'filled';
      case 'canceled':
      case 'expired':
      case 'rejected':
      case 'not_traded':
        return 'canceled';
      case 'partially_filled':
        return 'partial';
      default:
        return 'pending';
    }
  };

  return (
    <ErrorBoundary>
      <>
        {/* Recent Trades */}
        <div className="card fade-in">
          <div className="card-header">
            <h2 className="card-title">
              <i className="fas fa-exchange-alt"></i> Recent Orders
            </h2>
            <div className="card-actions">
              <div className="badge badge-outline">Last 5 orders</div>
            </div>
          </div>
          <div className="card-body p-0">
            <div className="table-container">
              <table>
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Symbol</th>
                    <th>Side</th>
                    <th>Type</th>
                    <th className="text-right">Quantity</th>
                    <th className="text-right">Price</th>
                    <th className="text-center">Status</th>
                  </tr>
                </thead>
                <tbody id="orders-table">
                  {trades.length === 0 ? (
                    <tr>
                      <td colSpan="7" className="text-center py-4 text-secondary">
                        <i className="fas fa-info-circle text-lg mb-2"></i>
                        <div>No trades available</div>
                      </td>
                    </tr>
                  ) : (
                    trades.map((trade, index) => (
                      <tr key={index}>
                        <td>{new Date(trade.timestamp).toLocaleDateString()}</td>
                        <td>
                          <div className="symbol-cell">
                            <div className="symbol-icon">{trade.symbol.substring(0, 2)}</div>
                            <div className="symbol-text">{trade.symbol}</div>
                          </div>
                        </td>
                        <td>
                          <div className={`order-side ${trade.action.toLowerCase()}`}>
                            {trade.action.toUpperCase()}
                          </div>
                        </td>
                        <td>Market</td>
                        <td className="text-right">{trade.quantity}</td>
                        <td className="text-right">{formatCurrency(trade.price)}</td>
                        <td className="text-center">
                          <div className={`order-status ${getOrderStatusClass(trade.status)}`}>
                            {trade.status ? trade.status.toUpperCase() : 'PENDING'}
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Trade Alerts */}
        <div className="card fade-in">
          <div className="card-header">
            <h2 className="card-title">
              <i className="fas fa-bell"></i> Trade Alerts
            </h2>
            <div className="card-actions">
              <button className="btn btn-sm btn-outline">
                <i className="fas fa-cog mr-1"></i> Configure
              </button>
            </div>
          </div>
          <div className="card-body">
            <div id="alerts-container">
              {alerts.length === 0 ? (
                <div className="text-center text-secondary">
                  <i className="fas fa-bell-slash text-lg mb-2"></i>
                  <div>No trade alerts available</div>
                </div>
              ) : (
                alerts.map(alert => (
                  <div key={alert.id} className={`alert alert-${alert.type}`}>
                    <div
                      className="alert-icon"
                      style={{
                        backgroundColor: `rgba(${
                          alert.type === 'success' ? '16,185,129' :
                          alert.type === 'danger' ? '239,68,68' :
                          '14,165,233'
                        },0.1)`,
                        color: `var(--color-${alert.type})`,
                      }}
                    >
                      <i className="fas fa-info-circle"></i>
                    </div>
                    <div className="alert-content">
                      <div className="alert-title">{alert.title}</div>
                      <p className="alert-message">{alert.message}</p>
                      {alert.meta && (
                        <div className="trade-alert-meta">
                          {alert.meta.map((item, idx) => (
                            <div key={idx} className="trade-alert-meta-item">
                              <i className={item.icon}></i> {item.text}
                            </div>
                          ))}
                        </div>
                      )}
                      <div className="alert-actions">
                        {alert.actions.map((action, idx) => (
                          <button
                            key={idx}
                            className={`btn btn-sm btn-${action.type}`}
                            onClick={() => handleAlertAction(alert.id, action.label)}
                          >
                            {action.label === 'Execute' && <i className="fas fa-play mr-1"></i>}
                            {action.label === 'Analyze' && <i className="fas fa-chart-bar mr-1"></i>}
                            {action.label === 'Dismiss' && <i className="fas fa-times mr-1"></i>}
                            {action.label === 'Set Up Alerts' && <i className="fas fa-bell mr-1"></i>}
                            {action.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </>
    </ErrorBoundary>
  );
}

export default Trades;